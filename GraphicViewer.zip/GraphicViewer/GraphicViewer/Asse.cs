﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GraphicViewer
{
    class Asse
    {
        public string Unità { get; set; }
        public string Dettaglio { get; set; }
        public int Max { get; set; }
        public int Min { get; set; }
        public int Origine { get; set; }
    }
}
