﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GraphicViewer
{
    class Coordinate
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
