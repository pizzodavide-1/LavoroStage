﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GraphicViewer
{
    class Grafico
    {
        public Asse X;
        public Asse Y;
    }
}
